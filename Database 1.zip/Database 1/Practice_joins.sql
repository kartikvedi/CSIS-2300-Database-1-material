-- Create Student table
CREATE TABLE Student (
    SID INT PRIMARY KEY,
    SName VARCHAR(255) NOT NULL
);

-- Create Course table
CREATE TABLE Course (
    CID INT PRIMARY KEY,
    CName VARCHAR(255) NOT NULL
);

-- Create Course_Section table
CREATE TABLE Course_Section (
    CID INT,
    SecID INT,
    SType VARCHAR(50),
    PRIMARY KEY (CID, SecID),
    FOREIGN KEY (CID) REFERENCES Course(CID)
);

-- Create Std_Enrolles_Sec table
CREATE TABLE Std_Enrolles_Sec (
    SID INT,
    CID INT,
    SecID INT,
    Grade VARCHAR(2),
    PRIMARY KEY (SID, CID, SecID),
    FOREIGN KEY (SID) REFERENCES Student(SID),
    FOREIGN KEY (CID, SecID) REFERENCES Course_Section(CID, SecID)
);

-- Insert values into Student table
INSERT INTO Student (SID, SName) VALUES
    (1, 'John Doe'),
    (2, 'Jane Smith'),
    (3, 'Bob Johnson');

-- Insert values into Course table
INSERT INTO Course (CID, CName) VALUES
    (101, 'Mathematics'),
    (102, 'Physics'),
    (103, 'Computer Science');

-- Insert values into Course_Section table
INSERT INTO Course_Section (CID, SecID, SType) VALUES
    (101, 1, 'Lecture'),
    (101, 2, 'Lab'),
    (102, 1, 'Lecture'),
    (103, 1, 'Lecture');

-- Insert values into Std_Enrolles_Sec table
INSERT INTO Std_Enrolles_Sec (SID, CID, SecID, Grade) VALUES
    (1, 101, 1, 'A'),
    (1, 102, 1, 'B+'),
    (2, 101, 1, 'A-'),
    (2, 103, 1, 'A'),
    (3, 102, 1, 'B');
    
SELECT s.SNAME,Count(e.SECID) as Count_Courses
FROM Student s LEFT JOIN Std_Enrolles_Sec e ON s.SID=E.SID
GROUP BY s.SNAME;

SELECT cs.CID,cs.SECID,cs.STYPE,Count(e.SID) as Student_Count
FROM Course_Section cs
LEFT JOIN  Std_Enrolles_Sec e on cs.CID=e.CID AND cs.SECID = e.SecID
GROUP BY cs.CID,cs.SECID,cs.STYPE
HAVING Student_Count >=1;

SELECT cs.CID,cs.SECID,cs.STYPE,s.SNAME
FROM Course_Section cs
JOIN  Std_Enrolles_Sec e on cs.CID=e.CID
LEFT JOIN Student s on e.SID=s.SID
GROUP BY cs.CID,cs.SECID,cs.STYPE,s.SNAME;


SELECT s.SNAME, e.SECID
FROM Student s
LEFT JOIN Std_Enrolles_Sec e ON s.SID = e.SID;

SELECT s.SNAME,e.SECID
FROM Student s LEFT JOIN Std_Enrolles_Sec e on s.SID=e.SID;

SELECT SName
FROM Student
Where SID NOT IN 
(SELECT DISTINCT SID 
FROM Std_Enrolles_Sec
);

SELECT SECID 
FROM Std_Enrolles_Sec
WHERE SID NOT IN 
(SELECT DISTINCT SID FROM Student);

SELECT s.SName,COUNT(e.SECID) As No_Sections_Enrolled
FROM Student s 
LEFT JOIN Std_Enrolles_Sec e ON s.SID=e.SID
GROUP BY s.SName;

SELECT Distinct s.SName
FROM Student s
RIGHT JOIN Std_Enrolles_Sec e on s.SID=e.SID
RIGHT JOIN Course c on e.CID=c.CID
WHERE c.CID IN (SELECT DISTINCT c.CID FROM Course_Section);

SELECT S.SID,S.SName
FROM Student S JOIN Std_Enrolles_Sec E ON  S.SID=E.SID
GROUP BY S.SID, S.SNAME
HAVING COUNT(DISTINCT E.CID) = (SELECT COUNT(DISTINCT CID)
								FROM Course_Section);




SELECT c.CID,COUNT(e.CID) AS no_of_students
FROM Course c
LEFT JOIN Std_Enrolles_Sec e on c.CID=e.CID
GROUP BY c.CID;

INSERT INTO Student (SID, SName) VALUES
    ((SELECT MAX(SID) + 1 FROM Student), 'Saeed Mirjalili');

-- Insert 'Saeed Mirjalili' into Course_Section table
INSERT INTO Course_Section (CID, SecID, SType) VALUES
    (101, 1, 'Lecture'),
    (102, 1, 'Lecture'),
    (103, 1, 'Lecture');

-- Assuming 'Saeed Mirjalili' enrolls in all the sections added above
INSERT INTO Std_Enrolles_Sec (SID, CID, SecID, Grade) VALUES
    ((SELECT SID FROM Student WHERE SName = 'Saeed Mirjalili'), 101, 1, 'A'),
    ((SELECT SID FROM Student WHERE SName = 'Saeed Mirjalili'), 102, 1, 'B+'),
    ((SELECT SID FROM Student WHERE SName = 'Saeed Mirjalili'), 103, 1, 'A');



SELECT S.SNAME  
FROM STUDENT S
JOIN STD_ENROLLES_SEC E ON S.SID = E.SID
WHERE E.CID IN (
	SELECT CID
    FROM STD_ENROLLES_SEC
    WHERE SID = (SELECT SID FROM STUDENT WHERE SNAME = 'Saeed Mirjalili')
    );

SELECT DISTINCT s.SName,c.CNAME
FROM Student s 
LEFT JOIN Std_Enrolles_Sec se ON s.SID=se.SID
LEFT JOIN Course c on se.CID=c.CID;

SELECT SNAME
FROM Student
WHERE SID IN  (SELECT SID FROM Std_Enrolles_Sec WHERE GRADE > (SELECT AVG(GRADE) FROM Std_Enrolles_Sec)
AND CID=(SELECT MAX(CID) FROM Std_Enrolles_Sec));


