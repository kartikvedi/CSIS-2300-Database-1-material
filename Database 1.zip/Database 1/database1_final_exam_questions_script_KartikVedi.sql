-- Name : Kartik Vedi
-- Student ID: 300374518


USE Clinic;

SELECT * FROM Patient ;
SELECT * FROM Doctor;
SELECT * FROM University;
SELECT * FROM  Patient_Visits_Doctor;
SELECT * FROM Doctor_Attended_University;

-- Query 1
SELECT * FROM Patient WHERE LName LIKE 'S%h';

-- Query 2
SELECT Count(DocID) AS 'Number of Male Doctors' FROM Doctor WHERE Gender = 'M';

-- Query 3
SELECT DocID,COUNT(PID) AS "Number of Patients"
FROM Patient_Visits_Doctor
GROUP BY DocID
ORDER BY COUNT(PID) ;

-- Query 4
SELECT DocID,COUNT(PID) AS "Number of Visits"
FROM Patient_Visits_Doctor
GROUP BY DocID
HAVING COUNT(PID) <= 3;

-- Query 5
SELECT D.DocID,D.FName,D.LName,COUNT(PD.PID) AS "Number of Patients"
FROM Doctor D INNER JOIN Patient_Visits_Doctor PD ON D.DocID=PD.DocID
GROUP BY  D.DocID,D.FName,D.LName;

-- Query 6
SELECT P.*,D.*
FROM Patient P 
LEFT JOIN Patient_Visits_Doctor PD ON P.PID=PD.PID
RIGHT JOIN Doctor D ON D.DocID=PD.DocID 
WHERE P.PID IS NOT NULL;

-- Query 7
SELECT P.*,D.*
FROM Patient P 
LEFT JOIN Patient_Visits_Doctor PD ON P.PID=PD.PID
RIGHT JOIN Doctor D ON D.DocID=PD.DocID 
WHERE P.PID IS NOT NULL AND D.Gender='F';

-- Query 8
SELECT D.*
FROM Doctor D
LEFT JOIN Patient_Visits_Doctor PD ON D.DocID=PD.DocID
WHERE PD.PID IS NULL;

-- Query 9
SELECT Distinct U.CityLocation 
FROM University U  
INNER JOIN Doctor_Attended_University DAU ON U.UCode = DAU.UCode;

-- Query 10
CREATE VIEW Doctor_Male
AS SELECT * FROM Doctor 
WHERE Gender='M';

SELECT * FROM Doctor_Male;

-- Query 11
SELECT D.*,DAU.Degree
FROM Doctor D,Doctor_Attended_University DAU
WHERE D.DocID = DAU.DocID AND  D.Gender='M' AND DAU.Degree='PhD';

-- Query 12
SELECT * FROM Patient
WHERE BirthDate IN (SELECT MIN(BirthDate) FROM Patient);

-- Query 13
SELECT DocID,Fname,LName 
FROM Doctor;

UPDATE Doctor
SET Gender = 'F' 
WHERE DocID IN (SELECT DocID FROM Doctor WHERE DocID='501');

-- Query 14
SELECT p.FName,p.LName,pvd.VisitDate 
FROM Patient p RIGHT JOIN Patient_Visits_Doctor pvd on p.PID = pvd.PID
WHERE pvd.Diagnosis='Flu';

-- Query 15
SELECT d.FName,d.LName,dau.UCode,dau.Degree
FROM Doctor d LEFT JOIN Doctor_Attended_University dau ON d.DocID=dau.DocID
ORDER BY d.DocID,dau.docID;





