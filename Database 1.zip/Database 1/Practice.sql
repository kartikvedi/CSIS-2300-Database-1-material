CREATE DATABASE Company;

USE Company;

CREATE TABLE Employees (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(255),
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Departments(DeptID)
);

CREATE TABLE Departments (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(255)
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    Product VARCHAR(255),
    EmpID INT,
    FOREIGN KEY (EmpID) REFERENCES Employees(EmpID)
);


INSERT INTO Employees (EmpID, EmpName, DeptID) VALUES
(1, 'Alice', 101),
(2, 'Bob', 102),
(3, 'Charlie', 101),
(4, 'David', 103);

INSERT INTO Departments (DeptID, DeptName) VALUES
(101, 'IT'),
(102, 'HR'),
(103, 'Finance');

INSERT INTO Orders (OrderID, Product, EmpID) VALUES
(1, 'Laptop', 1),
(2, 'Printer', 2),
(3, 'Monitor', 3),
(4, 'Mouse', 2);


SELECT * FROM Employees;
SELECT DISTINCT DeptName FROM Departments;
SELECT EmpName FROM EMPLOYEES WHERE DeptID=101;

SELECT e.EmpName,d.DeptName
FROM Employees e LEFT JOIN Departments d
on e.DeptID=d.DeptID;

SELECT e.EmpName,o.Product
FROM Employees e LEFT OUTER JOIN Orders o
on e.EmpID = o.EmpID;

INSERT INTO Employees (EmpID, EmpName, DeptID) VALUES (5, 'Eva', 102);

UPDATE Employees  SET DeptID = 103 WHERE EmpID = 4;

DELETE FROM Orders WHERE OrderID=3;

SELECT * FROM Orders ORDER BY OrderID LIMIT 2;

Select MIN(EmpID) as 'Minimum EMPID',MAX(EmpID) AS 'Maximum EMPID'
FROM Employees;

SELECT COUNT(EmpID) AS 'No of Employees'
FROM Employees
WHERE DeptID = 101;

SELECT COUNT(OrderID) AS 'Total No of Orders'
FROM Orders;

Select AVG(EmpID) 
FROM Employees;

Select EmpName 
From Employees
Where EmpName Like 'A%';

Select E.*,D.DeptName
From Employees E JOIN Departments D  
On E.DeptID=D.DeptID
WHERE D.DeptName IN('IT','HR');

SELECT E.EmpName,COUNT(O.OrderID) AS 'Total No of Orders'
FROM Employees E LEFT JOIN Orders O 
ON E.EmpID=O.EmpID
GROUP BY E.EmpName;

SELECT COUNT(O.OrderID) AS OrderCount,D.DeptName
FROM Departments D
LEFT JOIN Employees E ON D.DeptID=E.DeptID
LEFT JOIN Orders O ON E.EmpID=O.EmpID
GROUP BY D.DEPTNAME
ORDER BY OrderCount DESC;

CREATE VIEW EmployeeOrdersView AS
SELECT E.EmpName,O.OrderID
FROM Employees E RIGHT JOIN Orders O ON E.EmpID=O.EmpID;

SELECT * FROM EmployeeOrdersView;

CREATE VIEW HighValueOrdersView AS 
SELECT O.OrderID,O.Product,E.EmpName,
